package com.example.leafnovel

import android.view.View
//import androidx.recycleView
//class BookAdapter (ver books:List<Book>)
//
//class BookViewHolder(view: View):RecycleView.ViewHolder(view)
//data class Book(
//    val bookNum: String,
//    val booktitle: String,
//    val bookId: String,
//    val bookUrl: String,
//    val author: String,
//    val bookDescripe: String,
//    val updateTime: String
//)