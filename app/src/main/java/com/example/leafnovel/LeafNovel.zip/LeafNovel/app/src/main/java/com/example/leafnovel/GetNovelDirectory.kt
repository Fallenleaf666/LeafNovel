import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import org.jsoup.select.Elements
import java.net.URL
//import javax.print.DocFlavor

fun main () {
//    get dictery
    val doc : Document = Jsoup.connect("https://tw.uukanshu.com/b/141809/").get();
//    get chlisttag
    val chapterList : Element ?= doc.getElementById("chapterList");
    val chapters :Elements = chapterList!!.getElementsByTag("li")

//    get chapters
    var chList:MutableList<Elements> = mutableListOf()
    for(i in chapters){
        var c=i.getElementsByTag("a")
        if(c.toString()!="")
            chList.add(c)
    }
    val chNum = chList.size
    println("總共 $chNum 章")
//    get ch title
    for(i in chList){
        val title : String = i.text()
        val href : String = i.attr("href")
//        println(title+href)
    }

    RequestChText(chList.shuffled().first().attr("href"));

}

fun RequestChText(url:String){
//    val doc : Document = Jsoup.connect("https://tw.uukanshu.com"+url).get();
    val doc : Document = Jsoup.connect("https://tw.uukanshu.com/b/"+url+"/").get();
//    println(doc.text())
    val contentbox : Element? = doc.getElementById("contentbox");
    val contents : Elements = contentbox!!.getElementsByTag("p")
    for(i in contents){
        println(i.text())
        println()
    }
}

fun RequestSearchNovel(searchContent:String){
//    val doc : Document = Jsoup.connect("https://sj.uukanshu.com/search.aspx?k="+searchContent).get();
    val doc : Document = Jsoup.connect("https://t.uukanshu.com/search.aspx?k="+searchContent).get();
    val listbox : Element = doc.getElementById("bookList")
    val searchBooks : Elements = listbox.getElementsByTag("li")

    for(i in searchBooks){
        var bookNum = i.getElementsByClass("book_num").text()
        var tempDoc = i.getElementsByClass("name")
        var booktitle = tempDoc.attr("title")
        var bookId = tempDoc.attr("href")
        var bookUrl = tempDoc.attr("href").split("=")[1]
        var author =i.getElementsByClass("aut").text()
        var bookDescripe =i.getElementsByTag("p").first().getElementsByTag("a").first().text()
        var updateTime =i.getElementsByTag("p").first().getElementsByTag("span").first().text()

        println("順序"+bookNum)
        println("書名"+booktitle)
        println("Id"+bookId)
        println("bookurl"+bookUrl)
        println("作者"+author)
        println("描述"+bookDescripe)
        println("最後更新時間"+updateTime)
    }
}